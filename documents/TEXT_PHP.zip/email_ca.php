<?php

	return array(
		'welcomeSubject' => 'Benvingut a IASTracker',		//Subject del correu que s'envia al registrar-se
		'welcomeTitle' => 'Benvingut a IASTracker',	//Títol del correu que s'envia al registrar-se
		'activationText' => 'Hola :username,
		
Gràcies per registrer-te a IASTracker. Per a activar el teu compte clica al següent enllaç:

:link

Si no s'obre una nova finestra al navegador, pots copiar i enganxar l'enllaç al teu navegador.


<a href="http://www.iastracker.cat/net" rel="noreferrer" target="_blank"> www.iastracker.cat/net </a>',	//Cos del correu que s'envia al registrar-se
		'passwordReminderSubject' => 'IASTracker Reset password',	//Subject del correu que s'envia al restaurar la contrasenya
		'passwordReminderText' => 'Hola :username,
		
Hem rebut una petició per a modificar la teva paraula de pas. Ho pots fer a través de l'enllaç següent:

:link

Si no has solicitat aquest canvi, ignora aquest correu.

La teva paraula de pas no canviarà fins que no accedeixis a l'enllaç i creïs una de nova.

<a href="http://www.iastracker.cat/net" rel="noreferrer" target="_blank"> www.iastracker.cat/net </a>: '	//Cos del correu que s'envia al restaurar la contrasenya

	);